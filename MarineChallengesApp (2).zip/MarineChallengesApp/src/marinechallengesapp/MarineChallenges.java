/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package marinechallengesapp;

/**
 *
 * @author adamk
 */
public class MarineChallenges extends GlobalWarming {
    private String SeaLifeAffected, OverFishing, Industrialization;

    
    
    

    public MarineChallenges() {
    }

    public void setSeaLifeAffected(String SeaLifeAffected) {
        this.SeaLifeAffected = SeaLifeAffected;
    }

    public void setOverFishing(String OverFishing) {
        this.OverFishing = OverFishing;
    }

    public void setIndustrialization(String Industrialization) {
        this.Industrialization = Industrialization;
    }

    public String getSeaLifeAffected() {
        return SeaLifeAffected;
    }

    public String getOverFishing() {
        return OverFishing;
    }

    public String getIndustrialization() {
        return Industrialization;
    }
    
    
    
}
